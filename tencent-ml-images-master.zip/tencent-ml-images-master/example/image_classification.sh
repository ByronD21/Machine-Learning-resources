python2.7 image_classification.py \
 --images=data/im_list_for_classification.txt \
 --top_k_pred=5 \
 --model_dir=checkpoints/resnet.ckpt \
 --dictionary=data/imagenet2012_dictionary.txt
