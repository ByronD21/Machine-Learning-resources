python2.7 ./download_urls_multithreading.py --url_list=train_urls_tiny.txt --im_list=train_im_list_tiny.txt --num_threads=20 --save_dir='./images'
